using ApiCoaching.Models;
using System.Text.Json.Serialization;

namespace ApiCoaching.Dtos.Certifications
{
    /// <summary>
    /// GET /api/certifications/{id}/export
    /// Todo lo que necesita el PDF de una certificación: datos generales, criterios con
    /// sus respuestas, notas por columna y por criterio, puntaje final y aprobación.
    /// </summary>
    public class CertificationExportDto
    {
        public long Id { get; set; }

        [JsonConverter(typeof(JsonStringEnumConverter<CertificationStatus>))]
        public CertificationStatus Status { get; set; }
        public string StatusName { get; set; } = null!;

        public string TeamName { get; set; } = null!;
        public string? Area { get; set; }
        public string LeaderName { get; set; } = null!;
        public string? LeaderCode { get; set; }
        public string? LeaderPosition { get; set; }
        public string CertifierName { get; set; } = null!;
        public string FormatName { get; set; } = null!;

        public DateOnly Date { get; set; }           // fecha de aplicación (sin hora)
        public decimal MinScore { get; set; }
        public decimal Score { get; set; }           // nota final guardada al aplicar
        public bool Passes { get; set; }
        public string? Suggestions { get; set; }

        public DateTime RegisteredAt { get; set; }   // cuando el certificador la registró
        public string? ResolvedByName { get; set; }
        public DateTime? ResolvedAt { get; set; }

        public List<CertificationExportCriterionDto> Criteria { get; set; } = [];
    }

    public class CertificationExportCriterionDto
    {
        public string Id { get; set; } = null!;
        public string Name { get; set; } = null!;
        public int Weight { get; set; }
        public string? Description { get; set; }
        public string Calc { get; set; } = null!;              // ratio | ce | last
        public List<string> Columns { get; set; } = [];         // columnas de evaluación (sin "Observaciones")
        public List<CertificationExportIndicatorDto> Indicators { get; set; } = [];
        public List<CertificationColumnNoteDto> ColumnNotes { get; set; } = [];
        public decimal? Note { get; set; }                      // nota del criterio (0-100)
        public decimal Points { get; set; }                     // nota × peso / 100
    }

    public class CertificationExportIndicatorDto
    {
        public string Id { get; set; } = null!;
        public string Name { get; set; } = null!;
        public string Type { get; set; } = null!;
        public Dictionary<string, string?> Values { get; set; } = [];   // columna → valor registrado
        public string? Observation { get; set; }
    }

    public class CertificationColumnNoteDto
    {
        public string Column { get; set; } = null!;
        public decimal? Value { get; set; }
        public bool IsNa { get; set; }
    }
}
