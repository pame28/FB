using ApiCoaching.Constants;
using ApiCoaching.Dtos;
using ApiCoaching.Dtos.Certifications;
using ApiCoaching.Models;
using ApiCoaching.Repositories.Interfaces;
using System.Security.Claims;

namespace ApiCoaching.Endpoints
{
    public static class CertificationsEndpoints
    {
        public static void MapCertificationsEndpoints(this IEndpointRouteBuilder app)
        {
            var group = app.MapGroup("/api/certifications")
                .WithTags("Certifications")
                .RequireAuthorization();

            // Formatos
            group.MapGet("formats", GetFormats)
                .WithName("GetCertificationFormats")
                .WithSummary("Obtiene los formatos de certificaci\u00f3n con su estructura de criterios.")
                .Produces<ResponseObject<List<CertificationFormatDto>>>(StatusCodes.Status200OK);

            group.MapPost("formats", CreateFormat)
                .WithName("CreateCertificationFormat")
                .WithSummary("Crea un formato y desactiva el formato activo anterior del equipo.")
                .Produces<ResponseObject<object>>(StatusCodes.Status201Created)
                .Produces<ResponseObjectError>(StatusCodes.Status400BadRequest);

            group.MapPut("formats/{id:int}", UpdateFormat)
                .WithName("UpdateCertificationFormat")
                .WithSummary("Actualiza un formato; queda como el formato activo de su equipo.")
                .Produces<ResponseObject<object>>(StatusCodes.Status200OK)
                .Produces<ResponseObjectError>(StatusCodes.Status400BadRequest)
                .Produces<ResponseObjectError>(StatusCodes.Status404NotFound);

            group.MapDelete("formats/{id:int}", DeleteFormat)
                .WithName("DeleteCertificationFormat")
                .WithSummary("Elimina un formato; las certificaciones ya aplicadas conservan su informaci\u00f3n.")
                .Produces<ResponseObject<object>>(StatusCodes.Status200OK)
                .Produces<ResponseObjectError>(StatusCodes.Status404NotFound);

            // Gesti\u00f3n de certificadores
            group.MapGet("certifiers", GetCertifiers)
                .WithName("GetCertifiers")
                .WithSummary("Obtiene los certificadores designados con sus equipos; filtra por \u00e1rea y b\u00fasqueda por nombre o c\u00f3digo.")
                .Produces<ResponseObject<List<CertifierDto>>>(StatusCodes.Status200OK);

            group.MapGet("certifiers/teams", GetCertifierTeams)
                .WithName("GetCertifierTeamsByArea")
                .WithSummary("Obtiene los equipos de un \u00e1rea con su l\u00edder, miembros y cantidad de certificadores.")
                .Produces<ResponseObject<List<CertifierTeamDto>>>(StatusCodes.Status200OK)
                .Produces<ResponseObjectError>(StatusCodes.Status400BadRequest);

            group.MapGet("certifiers/candidates", GetCertifierCandidates)
                .WithName("GetCertifierCandidates")
                .WithSummary("Obtiene los usuarios activos de un área que pueden designarse como certificadores; búsqueda por nombre o código.")
                .Produces<ResponseObject<List<CertifierDto>>>(StatusCodes.Status200OK)
                .Produces<ResponseObjectError>(StatusCodes.Status400BadRequest);

            group.MapPost("certifiers", DesignateCertifier)
                .WithName("DesignateCertifier")
                .WithSummary("Designa a un usuario como certificador de equipos de su \u00e1rea.")
                .Produces<ResponseObject<object>>(StatusCodes.Status200OK)
                .Produces<ResponseObjectError>(StatusCodes.Status400BadRequest)
                .Produces<ResponseObjectError>(StatusCodes.Status404NotFound);

            group.MapDelete("certifiers/{userId}", RemoveCertifier)
                .WithName("RemoveCertifier")
                .WithSummary("Quita el rol de certificador; las certificaciones registradas no se afectan.")
                .Produces<ResponseObject<object>>(StatusCodes.Status200OK)
                .Produces<ResponseObjectError>(StatusCodes.Status404NotFound);

            // Aplicar certificaci\u00f3n
            group.MapGet("my-teams", GetMyTeams)
                .WithName("GetCertifierAssignedTeams")
                .WithSummary("Obtiene los equipos asignados al certificador autenticado con sus l\u00edderes y formato activo.")
                .Produces<ResponseObject<List<AssignedTeamDto>>>(StatusCodes.Status200OK);

            group.MapPost(string.Empty, Apply)
                .WithName("ApplyCertification")
                .WithSummary("Aplica una certificaci\u00f3n a un l\u00edder; el puntaje se calcula en el servidor y queda pendiente de aprobaci\u00f3n.")
                .Produces<ResponseObject<object>>(StatusCodes.Status201Created)
                .Produces<ResponseObjectError>(StatusCodes.Status400BadRequest)
                .Produces<ResponseObjectError>(StatusCodes.Status403Forbidden);

            // Historiales
            group.MapGet("mine", GetMine)
                .WithName("GetAssignedTeamsCertifications")
                .WithSummary("Historial de certificaciones de los equipos asignados al certificador, sin importar qui\u00e9n las aplic\u00f3.")
                .Produces<ResponseObject<List<CertificationDto>>>(StatusCodes.Status200OK);

            group.MapGet(string.Empty, GetAll)
                .WithName("GetAllCertifications")
                .WithSummary("Historial general de certificaciones de todos los equipos y \u00e1reas.")
                .Produces<ResponseObject<List<CertificationDto>>>(StatusCodes.Status200OK)
                .Produces<ResponseObjectError>(StatusCodes.Status400BadRequest);

            group.MapGet("{id:long}/breakdown", GetBreakdown)
                .WithName("GetCertificationBreakdown")
                .WithSummary("Obtiene el desglose del puntaje final por criterio de una certificación.")
                .Produces<ResponseObject<CertificationBreakdownDto>>(StatusCodes.Status200OK)
                .Produces<ResponseObjectError>(StatusCodes.Status404NotFound);

            group.MapGet("{id:long}/export", GetExport)
                .WithName("ExportCertification")
                .WithSummary("Obtiene la información completa de una certificación para generar su PDF: criterios, respuestas, notas por columna y por criterio, puntaje final y aprobación.")
                .Produces<ResponseObject<CertificationExportDto>>(StatusCodes.Status200OK)
                .Produces<ResponseObjectError>(StatusCodes.Status404NotFound);

            group.MapPost("{id:long}/approve", (long id, ICertificationsRepository repository, ClaimsPrincipal user, ILoggerFactory loggerFactory) =>
                    Resolve(id, true, repository, user, loggerFactory))
                .WithName("ApproveCertification")
                .WithSummary("Aprueba una certificaci\u00f3n pendiente y registra la auditor\u00eda.")
                .Produces<ResponseObject<object>>(StatusCodes.Status200OK)
                .Produces<ResponseObjectError>(StatusCodes.Status404NotFound)
                .Produces<ResponseObjectError>(StatusCodes.Status409Conflict);

            group.MapPost("{id:long}/reject", (long id, ICertificationsRepository repository, ClaimsPrincipal user, ILoggerFactory loggerFactory) =>
                    Resolve(id, false, repository, user, loggerFactory))
                .WithName("RejectCertification")
                .WithSummary("Rechaza una certificaci\u00f3n pendiente (queda como No aprobado) y registra la auditor\u00eda.")
                .Produces<ResponseObject<object>>(StatusCodes.Status200OK)
                .Produces<ResponseObjectError>(StatusCodes.Status404NotFound)
                .Produces<ResponseObjectError>(StatusCodes.Status409Conflict);
        }

        private static Task<IResult> GetFormats(ICertificationsRepository repository, ILoggerFactory loggerFactory) =>
            Execute(loggerFactory, "GetCertificationFormatsError", async () =>
                Ok(await repository.GetFormatsAsync()));

        private static Task<IResult> CreateFormat(
            SaveCertificationFormatRequestDto request, ICertificationsRepository repository,
            ClaimsPrincipal claimsPrincipal, ILoggerFactory loggerFactory) =>
            WithUser(claimsPrincipal, loggerFactory, "CreateCertificationFormatError", async userId =>
                Mutation(await repository.SaveFormatAsync(null, request, userId), 201, "Formato guardado correctamente."));

        private static Task<IResult> UpdateFormat(
            int id, SaveCertificationFormatRequestDto request, ICertificationsRepository repository,
            ClaimsPrincipal claimsPrincipal, ILoggerFactory loggerFactory) =>
            WithUser(claimsPrincipal, loggerFactory, "UpdateCertificationFormatError", async userId =>
                Mutation(await repository.SaveFormatAsync(id, request, userId), 200, "Formato guardado correctamente."));

        private static Task<IResult> DeleteFormat(
            int id, ICertificationsRepository repository, ClaimsPrincipal claimsPrincipal, ILoggerFactory loggerFactory) =>
            WithUser(claimsPrincipal, loggerFactory, "DeleteCertificationFormatError", async userId =>
                Mutation(await repository.DeleteFormatAsync(id, userId), 200, "Formato eliminado correctamente."));

        private static Task<IResult> GetCertifiers(
            int? areaId, string? search, ICertificationsRepository repository, ILoggerFactory loggerFactory) =>
            Execute(loggerFactory, "GetCertifiersError", async () =>
                Ok(await repository.GetCertifiersAsync(areaId, search)));

        private static Task<IResult> GetCertifierTeams(
            int? areaId, ICertificationsRepository repository, ILoggerFactory loggerFactory) =>
            Execute(loggerFactory, "GetCertifierTeamsError", async () =>
                areaId is null or <= 0
                    ? Error(400, "Debes indicar el \u00e1rea.")
                    : Ok(await repository.GetTeamsByAreaAsync(areaId.Value)));

        private static Task<IResult> GetCertifierCandidates(
            int? areaId, string? search, ICertificationsRepository repository, ILoggerFactory loggerFactory) =>
            Execute(loggerFactory, "GetCertifierCandidatesError", async () =>
                areaId is null or <= 0
                    ? Error(400, "Debes indicar el área.")
                    : Ok(await repository.GetCertifierCandidatesAsync(areaId.Value, search)));

        private static Task<IResult> DesignateCertifier(
            DesignateCertifierRequestDto request, ICertificationsRepository repository,
            ClaimsPrincipal claimsPrincipal, ILoggerFactory loggerFactory) =>
            WithUser(claimsPrincipal, loggerFactory, "DesignateCertifierError", async userId =>
                string.IsNullOrWhiteSpace(request?.UserId)
                    ? Error(400, "Debes indicar el usuario a designar.")
                    : Mutation(await repository.DesignateCertifierAsync(request.UserId.Trim(), request.TeamIds ?? [], userId),
                        200, "Certificador designado correctamente."));

        private static Task<IResult> RemoveCertifier(
            string userId, ICertificationsRepository repository, ClaimsPrincipal claimsPrincipal, ILoggerFactory loggerFactory) =>
            WithUser(claimsPrincipal, loggerFactory, "RemoveCertifierError", async currentUserId =>
                Mutation(await repository.RemoveCertifierAsync(userId, currentUserId), 200, "Rol de certificador quitado correctamente."));

        private static Task<IResult> GetMyTeams(
            ICertificationsRepository repository, ClaimsPrincipal claimsPrincipal, ILoggerFactory loggerFactory) =>
            WithUser(claimsPrincipal, loggerFactory, "GetCertifierAssignedTeamsError", async userId =>
                Ok(await repository.GetAssignedTeamsAsync(userId)));

        private static Task<IResult> Apply(
            ApplyCertificationRequestDto request, ICertificationsRepository repository,
            ClaimsPrincipal claimsPrincipal, ILoggerFactory loggerFactory) =>
            WithUser(claimsPrincipal, loggerFactory, "ApplyCertificationError", async userId =>
                request is null || request.TeamId <= 0 || string.IsNullOrWhiteSpace(request.LeaderUserId)
                    ? Error(400, "Debes indicar el equipo y el l\u00edder evaluado.")
                    : Mutation(await repository.ApplyAsync(request, userId), 201,
                        "Certificaci\u00f3n registrada correctamente \u2014 pendiente de aprobaci\u00f3n."));

        private static Task<IResult> GetMine(
            ICertificationsRepository repository, ClaimsPrincipal claimsPrincipal, ILoggerFactory loggerFactory) =>
            WithUser(claimsPrincipal, loggerFactory, "GetAssignedTeamsCertificationsError", async userId =>
                Ok(await repository.GetCertificationsAsync(userId, null, null, null, null, null)));

        private static Task<IResult> GetAll(
            int? areaId, int? teamId, string? certifierId, string? status, string? search,
            ICertificationsRepository repository, ILoggerFactory loggerFactory) =>
            Execute(loggerFactory, "GetAllCertificationsError", async () =>
            {
                CertificationStatus? parsed = null;
                if (!string.IsNullOrWhiteSpace(status))
                {
                    if (!Enum.TryParse<CertificationStatus>(status, true, out var value) || !Enum.IsDefined(value))
                    {
                        return Error(400, "El estado indicado no es v\u00e1lido. Use Pending, Approved o Rejected.");
                    }

                    parsed = value;
                }

                return Ok(await repository.GetCertificationsAsync(null, areaId, teamId, certifierId, parsed, search));
            });

        private static Task<IResult> GetBreakdown(long id, ICertificationsRepository repository, ILoggerFactory loggerFactory) =>
            Execute(loggerFactory, "GetCertificationBreakdownError", async () =>
                await repository.GetBreakdownAsync(id) is { } breakdown
                    ? Ok(breakdown)
                    : Error(404, "No se encontró la certificación."));

        private static Task<IResult> GetExport(long id, ICertificationsRepository repository, ILoggerFactory loggerFactory) =>
            Execute(loggerFactory, "ExportCertificationError", async () =>
                await repository.GetExportAsync(id) is { } data
                    ? Ok(data)
                    : Error(404, "No se encontró la certificación."));

        private static Task<IResult> Resolve(
            long id, bool approve, ICertificationsRepository repository, ClaimsPrincipal claimsPrincipal, ILoggerFactory loggerFactory) =>
            WithUser(claimsPrincipal, loggerFactory, "ResolveCertificationError", async userId =>
                Mutation(await repository.ResolveAsync(id, approve, userId), 200,
                    approve ? "Certificaci\u00f3n aprobada correctamente." : "Certificaci\u00f3n marcada como no aprobada."));

        private static IResult Ok<T>(T data) =>
            Results.Ok(new ResponseObject<T> { Code = 200, Message = "OK", Data = data });

        private static IResult Mutation(CertificationOperationResult result, int successCode, string successMessage)
        {
            if (result.Status == CertificationOperationStatus.Done)
            {
                return Results.Json(new ResponseObject<object>
                {
                    Code = successCode,
                    Message = successMessage,
                    Data = new { id = result.Id }
                }, statusCode: successCode);
            }

            return Error(result.Status switch
            {
                CertificationOperationStatus.NotFound => 404,
                CertificationOperationStatus.Forbidden => 403,
                CertificationOperationStatus.Invalid when result.Message?.Contains("pendiente") == true => 409,
                _ => 400
            }, result.Message!);
        }

        private static async Task<IResult> WithUser(
            ClaimsPrincipal claimsPrincipal, ILoggerFactory loggerFactory, string errorName, Func<string, Task<IResult>> action)
        {
            var userId = claimsPrincipal.FindFirstValue("userId") ?? claimsPrincipal.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrWhiteSpace(userId))
            {
                return Error(401, GenericErrors.UnauthorizedUserMessage);
            }

            return await Execute(loggerFactory, errorName, () => action(userId));
        }

        private static async Task<IResult> Execute(ILoggerFactory loggerFactory, string errorName, Func<Task<IResult>> action)
        {
            try
            {
                return await action();
            }
            catch (Exception ex)
            {
                loggerFactory.CreateLogger(typeof(CertificationsEndpoints)).LogError(ex, errorName);
                return Error(500, GenericErrors.InternalServerError);
            }
        }

        private static IResult Error(int code, string message) =>
            Results.Json(new ResponseObjectError { Code = code, Message = message }, statusCode: code);
    }
}
