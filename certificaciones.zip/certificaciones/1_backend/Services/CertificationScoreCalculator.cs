using ApiCoaching.Dtos.Certifications;
using System.Globalization;

namespace ApiCoaching.Services
{
    public static class CertificationScoreCalculator
    {
        private const string ObservationsColumn = "observaciones";

        public static IEnumerable<string> EvaluationColumns(FormatCriterionDto criterion) =>
            criterion.Columns.Where(c => !string.Equals(c.Trim(), ObservationsColumn, StringComparison.OrdinalIgnoreCase));

        public static string ResolveCalc(FormatCriterionDto criterion)
        {
            if (criterion.Calc is "ratio" or "ce" or "last")
            {
                return criterion.Calc;
            }

            if (criterion.Indicators.Count > 0 && criterion.Indicators.All(i => i.Type == "CE/NCE"))
            {
                return "ce";
            }

            return criterion.Indicators.Count >= 2 &&
                   criterion.Indicators[0].Type != "CE/NCE" && criterion.Indicators[1].Type != "CE/NCE" &&
                   criterion.Indicators[0].Type != "%" && criterion.Indicators[1].Type != "%"
                ? "ratio"
                : "last";
        }

        public static bool HasRating(
            FormatCriterionDto criterion,
            Dictionary<string, Dictionary<string, string>>? answers) =>
            answers is not null && criterion.Indicators.Any(ind =>
                answers.TryGetValue(ind.Id, out var cells) &&
                EvaluationColumns(criterion).Any(col => cells.TryGetValue(col, out var v) && !string.IsNullOrWhiteSpace(v)));

        // Nota de cada columna de evaluación: número (0-100), NA, o null si no hay datos
        public static List<CertificationColumnNoteDto> ColumnNotes(
            FormatCriterionDto criterion,
            Dictionary<string, Dictionary<string, string>>? answers)
        {
            answers ??= [];
            string? Cell(FormatIndicatorDto ind, string col) =>
                answers.TryGetValue(ind.Id, out var cells) && cells.TryGetValue(col, out var v) ? v?.Trim() : null;

            var result = new List<CertificationColumnNoteDto>();
            var columns = EvaluationColumns(criterion).ToList();

            switch (ResolveCalc(criterion))
            {
                case "ratio" when criterion.Indicators.Count >= 2:
                    foreach (var col in columns)
                    {
                        var p = Cell(criterion.Indicators[0], col);
                        var r = Cell(criterion.Indicators[1], col);
                        if (IsNa(p) || IsNa(r))
                        {
                            result.Add(new CertificationColumnNoteDto { Column = col, IsNa = true });
                            continue;
                        }

                        decimal? value = TryNum(p, out var pv) && pv > 0 && TryNum(r, out var rv)
                            ? Math.Min(100m, Round(rv / pv * 100m))
                            : null;
                        result.Add(new CertificationColumnNoteDto { Column = col, Value = value });
                    }
                    break;

                case "ce":
                    foreach (var col in columns)
                    {
                        var values = criterion.Indicators.Select(i => Cell(i, col)).ToList();
                        var ce = values.Count(v => string.Equals(v, "CE", StringComparison.OrdinalIgnoreCase));
                        var nce = values.Count(v => string.Equals(v, "NCE", StringComparison.OrdinalIgnoreCase));
                        result.Add(ce + nce > 0
                            ? new CertificationColumnNoteDto { Column = col, Value = Round((decimal)ce / (ce + nce) * 100m) }
                            : new CertificationColumnNoteDto { Column = col, IsNa = values.Any(IsNa) });
                    }
                    break;

                default:
                    var last = columns.LastOrDefault();
                    if (last is null) break;
                    var nums = criterion.Indicators
                        .Select(i => TryNum(Cell(i, last), out var v) ? (decimal?)v : null)
                        .Where(v => v.HasValue)
                        .Select(v => v!.Value)
                        .ToList();
                    result.Add(new CertificationColumnNoteDto
                    {
                        Column = last,
                        Value = nums.Count > 0 ? Math.Min(100m, Round(nums.Average())) : null
                    });
                    break;
            }

            return result;
        }

        // Nota del criterio en 0-100 = promedio de las notas numéricas de sus columnas; null si no hay datos o todo es NA
        public static decimal? CriterionScore(
            FormatCriterionDto criterion,
            Dictionary<string, Dictionary<string, string>>? answers)
        {
            var notes = ColumnNotes(criterion, answers)
                .Where(n => n.Value.HasValue)
                .Select(n => n.Value!.Value)
                .ToList();

            return notes.Count > 0 ? Round(notes.Average()) : null;
        }

        // Nota final = suma de (nota del criterio * peso / 100)
        public static List<CertificationBreakdownRowDto> Breakdown(
            IEnumerable<FormatCriterionDto> criteria,
            Dictionary<string, Dictionary<string, Dictionary<string, string>>> answers) =>
            [.. criteria.Select(c =>
            {
                answers.TryGetValue(c.Id, out var criterionAnswers);
                var note = CriterionScore(c, criterionAnswers);
                return new CertificationBreakdownRowDto
                {
                    Name = c.Name,
                    Weight = c.Weight,
                    Note = note,
                    Points = Round((note ?? 0m) * c.Weight / 100m)
                };
            })];

        public static decimal FinalScore(
            IEnumerable<FormatCriterionDto> criteria,
            Dictionary<string, Dictionary<string, Dictionary<string, string>>> answers) =>
            Round(Breakdown(criteria, answers).Sum(r => r.Points));

        private static bool IsNa(string? value) => string.Equals(value, "NA", StringComparison.OrdinalIgnoreCase);

        private static bool TryNum(string? value, out decimal number) =>
            decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out number);

        private static decimal Round(decimal value) => decimal.Round(value, 2, MidpointRounding.AwayFromZero);
    }
}
