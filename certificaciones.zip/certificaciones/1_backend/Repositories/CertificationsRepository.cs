using ApiCoaching.Data;
using ApiCoaching.Dtos.Certifications;
using ApiCoaching.Models;
using ApiCoaching.Repositories.Interfaces;
using ApiCoaching.Services;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace ApiCoaching.Repositories
{
    public class CertificationsRepository(AppDbContext dbContext) : ICertificationsRepository
    {
        private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

        private readonly AppDbContext _dbContext = dbContext;

        private static CertificationOperationResult Fail(CertificationOperationStatus status, string message) => new(status, message);

        private void AddAudit(OperationType operation, string modelName, string endpointFunction, object model, string userId)
        {
            _dbContext.ModelsLogs.Add(new ModelLog
            {
                OperationType = operation,
                ModelName = modelName,
                EndpointFunction = endpointFunction,
                JsonModel = JsonSerializer.Serialize(model, JsonOptions),
                OperationDate = DateTime.Now,
                UserId = userId
            });
        }

        /* ===================== Formatos ===================== */

        private async Task<List<CertificationFormatDto>> QueryFormatsAsync(IQueryable<CertificationFormat> query)
        {
            var rows = await query
                .AsNoTracking()
                .OrderByDescending(f => f.CreatedAt)
                .Select(f => new
                {
                    f.Id,
                    f.Name,
                    f.TeamId,
                    TeamName = f.Team.Name,
                    AreaId = f.Team.CompanyAreaId,
                    Area = f.Team.CompanyArea.Name,
                    CreatedByName = _dbContext.Users
                        .Where(u => u.Id == f.CreatedBy)
                        .Select(u => u.FullName ?? u.FirstName + " " + u.LastName)
                        .FirstOrDefault(),
                    f.CreatedAt,
                    f.IsActive,
                    f.MinScore,
                    f.FinalFormula,
                    f.CriteriaJson
                })
                .ToListAsync();

            return [.. rows.Select(row => new CertificationFormatDto
            {
                Id = row.Id,
                Name = row.Name,
                TeamId = row.TeamId,
                Team = row.TeamName,
                AreaId = row.AreaId,
                Area = row.Area,
                CreatedBy = row.CreatedByName,
                Date = row.CreatedAt,
                Status = row.IsActive ? "Activo" : "Inactivo",
                MinScore = row.MinScore,
                FinalFormula = row.FinalFormula,
                Criteria = JsonSerializer.Deserialize<List<FormatCriterionDto>>(row.CriteriaJson, JsonOptions) ?? []
            })];
        }

        public Task<List<CertificationFormatDto>> GetFormatsAsync() => QueryFormatsAsync(_dbContext.CertificationFormats);

        public async Task<CertificationOperationResult> SaveFormatAsync(
            int? id, SaveCertificationFormatRequestDto request, string currentUserId)
        {
            var name = request.Name?.Trim();
            if (string.IsNullOrEmpty(name) || name.Length > 150)
            {
                return Fail(CertificationOperationStatus.Invalid, "El nombre del formato es obligatorio (m\u00e1ximo 150 caracteres).");
            }

            if (string.IsNullOrWhiteSpace(request.FinalFormula))
            {
                return Fail(CertificationOperationStatus.Invalid, "Debes describir c\u00f3mo se calcula la nota final.");
            }

            if (request.MinScore < 0 || request.MinScore > 100)
            {
                return Fail(CertificationOperationStatus.Invalid, "La nota m\u00ednima debe estar entre 0 y 100.");
            }

            if (request.Criteria.Count == 0 || request.Criteria.Any(c => string.IsNullOrWhiteSpace(c.Name)))
            {
                return Fail(CertificationOperationStatus.Invalid, "Cada criterio debe tener un nombre.");
            }

            if (request.Criteria.Sum(c => c.Weight) != 100 || request.Criteria.Any(c => c.Weight < 0))
            {
                return Fail(CertificationOperationStatus.Invalid, "Los pesos de los criterios deben sumar 100%.");
            }

            if (request.Criteria.Any(c => c.Indicators.Count == 0 || c.Indicators.Any(i => string.IsNullOrWhiteSpace(i.Name)) ||
                !CertificationScoreCalculator.EvaluationColumns(c).Any()))
            {
                return Fail(CertificationOperationStatus.Invalid, "Cada criterio necesita al menos una columna de evaluaci\u00f3n y indicadores con nombre.");
            }

            if (!await _dbContext.Teams.AnyAsync(t => t.Id == request.TeamId))
            {
                return Fail(CertificationOperationStatus.Invalid, "El equipo indicado no existe.");
            }

            foreach (var criterion in request.Criteria)
            {
                if (string.IsNullOrWhiteSpace(criterion.Id)) criterion.Id = Guid.NewGuid().ToString("N");
                foreach (var indicator in criterion.Indicators.Where(i => string.IsNullOrWhiteSpace(i.Id)))
                {
                    indicator.Id = Guid.NewGuid().ToString("N");
                }
            }

            var now = DateTime.UtcNow;
            CertificationFormat format;

            if (id.HasValue)
            {
                var existing = await _dbContext.CertificationFormats.FirstOrDefaultAsync(f => f.Id == id.Value);
                if (existing is null)
                {
                    return Fail(CertificationOperationStatus.NotFound, "No se encontr\u00f3 el formato de certificaci\u00f3n.");
                }

                format = existing;
                format.LastModifiedAt = now;
                format.LastModifiedBy = currentUserId;
            }
            else
            {
                format = new CertificationFormat { CreatedAt = now, CreatedBy = currentUserId };
                _dbContext.CertificationFormats.Add(format);
            }

            format.Name = name;
            format.TeamId = request.TeamId;
            format.IsActive = true;
            format.MinScore = request.MinScore;
            format.FinalFormula = request.FinalFormula.Trim();
            format.CriteriaJson = JsonSerializer.Serialize(request.Criteria, JsonOptions);

            // Solo un formato activo por equipo
            var others = await _dbContext.CertificationFormats
                .Where(f => f.TeamId == request.TeamId && f.IsActive && (!id.HasValue || f.Id != id.Value))
                .ToListAsync();
            foreach (var other in others)
            {
                other.IsActive = false;
                other.LastModifiedAt = now;
                other.LastModifiedBy = currentUserId;
            }

            AddAudit(id.HasValue ? OperationType.Update : OperationType.Create, "CertFormat", nameof(SaveFormatAsync),
                new { format.Name, format.TeamId, request.MinScore, Deactivated = others.Select(o => o.Id) }, currentUserId);

            await _dbContext.SaveChangesAsync();
            return new(CertificationOperationStatus.Done, Id: format.Id);
        }

        public async Task<CertificationOperationResult> DeleteFormatAsync(int id, string currentUserId)
        {
            var format = await _dbContext.CertificationFormats.FirstOrDefaultAsync(f => f.Id == id);
            if (format is null)
            {
                return Fail(CertificationOperationStatus.NotFound, "No se encontr\u00f3 el formato de certificaci\u00f3n.");
            }

            AddAudit(OperationType.Delete, "CertFormat", nameof(DeleteFormatAsync),
                new { format.Id, format.Name, format.TeamId }, currentUserId);

            _dbContext.CertificationFormats.Remove(format);
            await _dbContext.SaveChangesAsync();
            return new(CertificationOperationStatus.Done, Id: id);
        }

        /* ===================== Certificadores ===================== */

        public async Task<List<CertifierDto>> GetCertifiersAsync(int? areaId, string? search)
        {
            var assignments = await _dbContext.TeamCertifiers
                .AsNoTracking()
                .Select(x => new { x.CertifierUserId, x.TeamId })
                .ToListAsync();

            var userIds = assignments.Select(x => x.CertifierUserId).Distinct().ToList();

            var users = _dbContext.Users.AsNoTracking().Where(u => userIds.Contains(u.Id));

            if (areaId.HasValue)
            {
                users = users.Where(u => u.CompanyAreaId == areaId.Value);
            }

            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = search.Trim();
                users = users.Where(u =>
                    (u.EmployeeCode != null && u.EmployeeCode.Contains(term)) ||
                    (u.FullName != null && u.FullName.Contains(term)) ||
                    (u.FirstName + " " + u.LastName).Contains(term));
            }

            var rows = await users
                .OrderBy(u => u.FirstName)
                .ThenBy(u => u.LastName)
                .Select(u => new
                {
                    u.Id,
                    u.EmployeeCode,
                    Name = u.FullName ?? u.FirstName + " " + u.LastName,
                    Position = u.CompanyPosition == null ? null : u.CompanyPosition.Name,
                    u.CompanyAreaId,
                    Area = u.CompanyArea == null ? null : u.CompanyArea.Name,
                    Status = u.Status.ToString()
                })
                .ToListAsync();

            var applied = await _dbContext.Certifications
                .AsNoTracking()
                .Where(c => userIds.Contains(c.CertifierUserId))
                .GroupBy(c => c.CertifierUserId)
                .Select(g => new { UserId = g.Key, Count = g.Count() })
                .ToDictionaryAsync(x => x.UserId, x => x.Count);

            return [.. rows.Select(row => new CertifierDto
            {
                Id = row.Id,
                Code = row.EmployeeCode,
                Name = row.Name,
                Position = row.Position,
                AreaId = row.CompanyAreaId,
                Area = row.Area,
                Status = row.Status,
                Applied = applied.GetValueOrDefault(row.Id),
                TeamIds = [.. assignments.Where(a => a.CertifierUserId == row.Id).Select(a => a.TeamId)]
            })];
        }

        public async Task<List<CertifierTeamDto>> GetTeamsByAreaAsync(int areaId)
        {
            return await _dbContext.Teams
                .AsNoTracking()
                .Where(t => t.CompanyAreaId == areaId)
                .OrderBy(t => t.Name)
                .Select(t => new CertifierTeamDto
                {
                    Id = t.Id,
                    Name = t.Name,
                    AreaId = t.CompanyAreaId,
                    Area = t.CompanyArea.Name,
                    Leader = t.Leaders
                        .Select(l => l.User.FullName ?? l.User.FirstName + " " + l.User.LastName)
                        .FirstOrDefault(),
                    Members = t.Members.Count,
                    Certifiers = _dbContext.TeamCertifiers.Count(c => c.TeamId == t.Id)
                })
                .ToListAsync();
        }

        public async Task<List<CertifierDto>> GetCertifierCandidatesAsync(int areaId, string? search)
        {
            var users = _dbContext.Users.AsNoTracking()
                .Where(u => u.CompanyAreaId == areaId && u.Status == UserStatus.Activo);

            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = search.Trim();
                users = users.Where(u =>
                    (u.EmployeeCode != null && u.EmployeeCode.Contains(term)) ||
                    (u.FullName != null && u.FullName.Contains(term)) ||
                    (u.FirstName + " " + u.LastName).Contains(term));
            }

            return await users
                .OrderBy(u => u.FirstName)
                .ThenBy(u => u.LastName)
                .Take(50)
                .Select(u => new CertifierDto
                {
                    Id = u.Id,
                    Code = u.EmployeeCode,
                    Name = u.FullName ?? u.FirstName + " " + u.LastName,
                    Position = u.CompanyPosition == null ? null : u.CompanyPosition.Name,
                    AreaId = u.CompanyAreaId,
                    Area = u.CompanyArea == null ? null : u.CompanyArea.Name,
                    Status = u.Status.ToString()
                })
                .ToListAsync();
        }

        public async Task<CertificationOperationResult> DesignateCertifierAsync(
            string userId, List<int> teamIds, string currentUserId)
        {
            var user = await _dbContext.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == userId);
            if (user is null)
            {
                return Fail(CertificationOperationStatus.NotFound, "No se encontr\u00f3 el usuario.");
            }

            if (user.Status != UserStatus.Activo)
            {
                return Fail(CertificationOperationStatus.Invalid, "Solo se puede designar como certificador a usuarios activos.");
            }

            var ids = teamIds.Distinct().ToList();
            if (ids.Count == 0)
            {
                return Fail(CertificationOperationStatus.Invalid, "Debes seleccionar al menos un equipo.");
            }

            var teams = await _dbContext.Teams.AsNoTracking().Where(t => ids.Contains(t.Id)).ToListAsync();
            if (teams.Count != ids.Count)
            {
                return Fail(CertificationOperationStatus.Invalid, "Uno o m\u00e1s equipos no existen.");
            }

            if (teams.Any(t => t.CompanyAreaId != user.CompanyAreaId))
            {
                return Fail(CertificationOperationStatus.Invalid, "Un certificador solo puede gestionar equipos de su \u00e1rea.");
            }

            var existing = await _dbContext.TeamCertifiers
                .Where(c => c.CertifierUserId == userId && ids.Contains(c.TeamId))
                .Select(c => c.TeamId)
                .ToListAsync();

            var now = DateTime.UtcNow;
            var added = ids.Except(existing).ToList();
            foreach (var teamId in added)
            {
                _dbContext.TeamCertifiers.Add(new TeamCertifier
                {
                    TeamId = teamId,
                    CertifierUserId = userId,
                    DesignatedAt = now,
                    DesignatedBy = currentUserId
                });
            }

            AddAudit(OperationType.Create, nameof(TeamCertifier), nameof(DesignateCertifierAsync),
                new { CertifierUserId = userId, TeamIds = added }, currentUserId);

            await _dbContext.SaveChangesAsync();
            return new(CertificationOperationStatus.Done);
        }

        public async Task<CertificationOperationResult> RemoveCertifierAsync(string userId, string currentUserId)
        {
            var rows = await _dbContext.TeamCertifiers.Where(c => c.CertifierUserId == userId).ToListAsync();
            if (rows.Count == 0)
            {
                return Fail(CertificationOperationStatus.NotFound, "El usuario no es certificador.");
            }

            AddAudit(OperationType.Delete, nameof(TeamCertifier), nameof(RemoveCertifierAsync),
                new { CertifierUserId = userId, TeamIds = rows.Select(r => r.TeamId) }, currentUserId);

            _dbContext.TeamCertifiers.RemoveRange(rows);
            await _dbContext.SaveChangesAsync();
            return new(CertificationOperationStatus.Done);
        }

        /* ===================== Aplicar certificaci\u00f3n ===================== */

        public async Task<List<AssignedTeamDto>> GetAssignedTeamsAsync(string certifierUserId)
        {
            var teamIds = await _dbContext.TeamCertifiers
                .AsNoTracking()
                .Where(c => c.CertifierUserId == certifierUserId)
                .Select(c => c.TeamId)
                .ToListAsync();

            if (teamIds.Count == 0)
            {
                return [];
            }

            var teams = await _dbContext.Teams
                .AsNoTracking()
                .Where(t => teamIds.Contains(t.Id))
                .OrderBy(t => t.Name)
                .Select(t => new AssignedTeamDto
                {
                    Id = t.Id,
                    Name = t.Name,
                    AreaId = t.CompanyAreaId,
                    Area = t.CompanyArea.Name,
                    Members = t.Members.Count,
                    Leaders = t.Leaders.Select(l => new AssignedTeamLeaderDto
                    {
                        Id = l.LeaderUserId,
                        Name = l.User.FullName ?? l.User.FirstName + " " + l.User.LastName,
                        Role = l.User.CompanyPosition == null ? null : l.User.CompanyPosition.Name,
                        Code = l.User.EmployeeCode
                    }).ToList()
                })
                .ToListAsync();

            var formats = await QueryFormatsAsync(_dbContext.CertificationFormats.Where(f => teamIds.Contains(f.TeamId) && f.IsActive));
            foreach (var team in teams)
            {
                team.Format = formats.FirstOrDefault(f => f.TeamId == team.Id);
            }

            return teams;
        }

        public async Task<CertificationOperationResult> ApplyAsync(ApplyCertificationRequestDto request, string certifierUserId)
        {
            if (!await _dbContext.TeamCertifiers.AnyAsync(c => c.TeamId == request.TeamId && c.CertifierUserId == certifierUserId))
            {
                return Fail(CertificationOperationStatus.Forbidden, "Solo puedes aplicar certificaciones a los equipos que tienes asignados como certificador.");
            }

            if (!await _dbContext.TeamsLeaders.AnyAsync(l => l.TeamId == request.TeamId && l.LeaderUserId == request.LeaderUserId))
            {
                return Fail(CertificationOperationStatus.Invalid, "El l\u00edder indicado no pertenece al equipo.");
            }

            if (request.Date == default)
            {
                return Fail(CertificationOperationStatus.Invalid, "La fecha de aplicaci\u00f3n es obligatoria.");
            }

            if (request.Suggestions?.Length > 2000)
            {
                return Fail(CertificationOperationStatus.Invalid, "Las sugerencias no pueden superar los 2000 caracteres.");
            }

            var format = await _dbContext.CertificationFormats
                .AsNoTracking()
                .FirstOrDefaultAsync(f => f.TeamId == request.TeamId && f.IsActive);
            if (format is null)
            {
                return Fail(CertificationOperationStatus.Invalid, "El equipo no tiene un formato activo asignado.");
            }

            var criteria = JsonSerializer.Deserialize<List<FormatCriterionDto>>(format.CriteriaJson, JsonOptions) ?? [];
            var missing = criteria.FirstOrDefault(c =>
                !CertificationScoreCalculator.HasRating(c, request.Answers.GetValueOrDefault(c.Id)));
            if (missing is not null)
            {
                return Fail(CertificationOperationStatus.Invalid, $"Registra al menos una calificaci\u00f3n en el criterio \"{missing.Name}\".");
            }

            var now = DateTime.UtcNow;
            var certification = new Certification
            {
                TeamId = request.TeamId,
                LeaderUserId = request.LeaderUserId,
                CertifierUserId = certifierUserId,
                FormatId = format.Id,
                FormatName = format.Name,
                MinScore = format.MinScore,
                CertificationDate = request.Date.Date,
                Status = CertificationStatus.Pending,
                Score = CertificationScoreCalculator.FinalScore(criteria, request.Answers),
                BreakdownJson = JsonSerializer.Serialize(CertificationScoreCalculator.Breakdown(criteria, request.Answers), JsonOptions),
                Suggestions = request.Suggestions?.Trim(),
                AnswersJson = JsonSerializer.Serialize(request.Answers, JsonOptions),
                CriteriaJson = format.CriteriaJson,
                CreatedAt = now,
                CreatedBy = certifierUserId
            };

            _dbContext.Certifications.Add(certification);
            AddAudit(OperationType.Create, nameof(Certification), nameof(ApplyAsync),
                new { certification.TeamId, certification.LeaderUserId, certification.FormatName, certification.Score, Status = "Aplicada" },
                certifierUserId);

            await _dbContext.SaveChangesAsync();
            return new(CertificationOperationStatus.Done, Id: certification.Id);
        }

        /* ===================== Historial y aprobaci\u00f3n ===================== */

        public async Task<List<CertificationDto>> GetCertificationsAsync(
            string? assignedToCertifierId, int? areaId, int? teamId, string? certifierId,
            CertificationStatus? status, string? search)
        {
            var query = _dbContext.Certifications.AsNoTracking().AsQueryable();

            if (!string.IsNullOrWhiteSpace(assignedToCertifierId))
            {
                query = query.Where(c => _dbContext.TeamCertifiers.Any(tc =>
                    tc.TeamId == c.TeamId && tc.CertifierUserId == assignedToCertifierId));
            }

            if (areaId.HasValue) query = query.Where(c => c.Team.CompanyAreaId == areaId.Value);
            if (teamId.HasValue) query = query.Where(c => c.TeamId == teamId.Value);
            if (!string.IsNullOrWhiteSpace(certifierId)) query = query.Where(c => c.CertifierUserId == certifierId);
            if (status.HasValue) query = query.Where(c => c.Status == status.Value);

            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = search.Trim();
                query = query.Where(c =>
                    (c.Leader.FullName != null && c.Leader.FullName.Contains(term)) ||
                    (c.Leader.FirstName + " " + c.Leader.LastName).Contains(term));
            }

            var rows = await query
                .OrderByDescending(c => c.CertificationDate)
                .ThenByDescending(c => c.Id)
                .Select(c => new CertificationDto
                {
                    Id = c.Id,
                    TeamId = c.TeamId,
                    TeamName = c.Team.Name,
                    AreaId = c.Team.CompanyAreaId,
                    Area = c.Team.CompanyArea.Name,
                    LeaderId = c.LeaderUserId,
                    LeaderName = c.Leader.FullName ?? c.Leader.FirstName + " " + c.Leader.LastName,
                    CertifierId = c.CertifierUserId,
                    Certifier = c.Certifier.FullName ?? c.Certifier.FirstName + " " + c.Certifier.LastName,
                    FormatName = c.FormatName,
                    MinScore = c.MinScore,
                    Date = c.CertificationDate,
                    Status = c.Status,
                    // El puntaje solo se expone una vez resuelta la certificaci\u00f3n
                    Score = c.Status == CertificationStatus.Pending ? null : c.Score
                })
                .ToListAsync();

            return rows;
        }

        public async Task<CertificationBreakdownDto?> GetBreakdownAsync(long id)
        {
            var row = await _dbContext.Certifications
                .AsNoTracking()
                .Where(c => c.Id == id)
                .Select(c => new { c.Score, c.MinScore, c.BreakdownJson })
                .FirstOrDefaultAsync();

            if (row is null)
            {
                return null;
            }

            return new CertificationBreakdownDto
            {
                Total = row.Score,
                MinScore = row.MinScore,
                Criteria = row.BreakdownJson is null
                    ? []
                    : JsonSerializer.Deserialize<List<CertificationBreakdownRowDto>>(row.BreakdownJson, JsonOptions) ?? []
            };
        }

        /* ===================== Exportar (PDF) ===================== */

        public async Task<CertificationExportDto?> GetExportAsync(long id)
        {
            var row = await _dbContext.Certifications
                .AsNoTracking()
                .Where(c => c.Id == id)
                .Select(c => new
                {
                    c.Id,
                    c.Status,
                    c.CertificationDate,
                    c.MinScore,
                    c.Score,
                    c.Suggestions,
                    c.AnswersJson,
                    c.FormatName,
                    c.CreatedAt,
                    c.ResolvedAt,
                    // Copia guardada al aplicar; las certificaciones anteriores a la copia usan el formato
                    CriteriaJson = c.CriteriaJson ?? (c.Format == null ? null : c.Format.CriteriaJson),
                    TeamName = c.Team.Name,
                    Area = c.Team.CompanyArea.Name,
                    LeaderName = c.Leader.FullName ?? c.Leader.FirstName + " " + c.Leader.LastName,
                    LeaderCode = c.Leader.EmployeeCode,
                    LeaderPosition = c.Leader.CompanyPosition == null ? null : c.Leader.CompanyPosition.Name,
                    CertifierName = c.Certifier.FullName ?? c.Certifier.FirstName + " " + c.Certifier.LastName,
                    ResolvedByName = _dbContext.Users
                        .Where(u => u.Id == c.ResolvedBy)
                        .Select(u => u.FullName ?? u.FirstName + " " + u.LastName)
                        .FirstOrDefault()
                })
                .FirstOrDefaultAsync();

            if (row is null)
            {
                return null;
            }

            var criteria = string.IsNullOrWhiteSpace(row.CriteriaJson)
                ? new List<FormatCriterionDto>()
                : JsonSerializer.Deserialize<List<FormatCriterionDto>>(row.CriteriaJson, JsonOptions)
                    ?? new List<FormatCriterionDto>();

            var answers = JsonSerializer.Deserialize<
                Dictionary<string, Dictionary<string, Dictionary<string, string>>>>(row.AnswersJson, JsonOptions)
                ?? new Dictionary<string, Dictionary<string, Dictionary<string, string>>>();

            return new CertificationExportDto
            {
                Id = row.Id,
                Status = row.Status,
                StatusName = row.Status switch
                {
                    CertificationStatus.Pending => "Pendiente aprobación",
                    CertificationStatus.Approved => "Aprobado",
                    _ => "No aprobado"
                },
                TeamName = row.TeamName,
                Area = row.Area,
                LeaderName = row.LeaderName,
                LeaderCode = row.LeaderCode,
                LeaderPosition = row.LeaderPosition,
                CertifierName = row.CertifierName,
                FormatName = row.FormatName,
                Date = DateOnly.FromDateTime(row.CertificationDate),
                MinScore = row.MinScore,
                Score = row.Score,
                Passes = row.Score >= row.MinScore,
                Suggestions = row.Suggestions,
                RegisteredAt = row.CreatedAt,
                ResolvedByName = row.ResolvedByName,
                ResolvedAt = row.ResolvedAt,
                Criteria = [.. criteria.Select(c => MapExportCriterion(c, answers.GetValueOrDefault(c.Id)))]
            };
        }

        private static CertificationExportCriterionDto MapExportCriterion(
            FormatCriterionDto criterion,
            Dictionary<string, Dictionary<string, string>>? answers)
        {
            answers ??= new Dictionary<string, Dictionary<string, string>>();
            var columns = CertificationScoreCalculator.EvaluationColumns(criterion).ToList();
            var note = CertificationScoreCalculator.CriterionScore(criterion, answers);

            return new CertificationExportCriterionDto
            {
                Id = criterion.Id,
                Name = criterion.Name,
                Weight = criterion.Weight,
                Description = criterion.Description,
                Calc = CertificationScoreCalculator.ResolveCalc(criterion),
                Columns = columns,
                Indicators = [.. criterion.Indicators.Select(indicator =>
                {
                    var cells = answers.GetValueOrDefault(indicator.Id) ?? new Dictionary<string, string>();
                    var values = new Dictionary<string, string?>();
                    foreach (var column in columns)
                    {
                        values[column] = cells.GetValueOrDefault(column);
                    }

                    return new CertificationExportIndicatorDto
                    {
                        Id = indicator.Id,
                        Name = indicator.Name,
                        Type = indicator.Type,
                        Values = values,
                        Observation = cells.GetValueOrDefault("__obs")
                    };
                })],
                ColumnNotes = CertificationScoreCalculator.ColumnNotes(criterion, answers),
                Note = note,
                Points = decimal.Round((note ?? 0m) * criterion.Weight / 100m, 2, MidpointRounding.AwayFromZero)
            };
        }

        public async Task<CertificationOperationResult> ResolveAsync(long id, bool approve, string currentUserId)
        {
            var certification = await _dbContext.Certifications.FirstOrDefaultAsync(c => c.Id == id);
            if (certification is null)
            {
                return Fail(CertificationOperationStatus.NotFound, "No se encontr\u00f3 la certificaci\u00f3n.");
            }

            if (certification.Status != CertificationStatus.Pending)
            {
                return Fail(CertificationOperationStatus.Invalid, "Solo se puede aprobar o rechazar una certificaci\u00f3n pendiente de aprobaci\u00f3n.");
            }

            var now = DateTime.UtcNow;
            certification.Status = approve ? CertificationStatus.Approved : CertificationStatus.Rejected;
            certification.ResolvedAt = now;
            certification.ResolvedBy = currentUserId;
            certification.LastModifiedAt = now;
            certification.LastModifiedBy = currentUserId;

            AddAudit(OperationType.Update, nameof(Certification), nameof(ResolveAsync),
                new
                {
                    certification.Id,
                    certification.TeamId,
                    certification.LeaderUserId,
                    PreviousStatus = CertificationStatus.Pending.ToString(),
                    NewStatus = certification.Status.ToString(),
                    Action = approve ? "Aprobada" : "Rechazada"
                }, currentUserId);

            await _dbContext.SaveChangesAsync();
            return new(CertificationOperationStatus.Done, Id: id);
        }
    }
}
