using ApiCoaching.Dtos.Certifications;
using ApiCoaching.Models;

namespace ApiCoaching.Repositories.Interfaces
{
    public enum CertificationOperationStatus
    {
        Done,
        NotFound,
        Invalid,
        Forbidden
    }

    public sealed record CertificationOperationResult(
        CertificationOperationStatus Status, string? Message = null, long? Id = null);

    public interface ICertificationsRepository
    {
        Task<List<CertificationFormatDto>> GetFormatsAsync();

        Task<CertificationOperationResult> SaveFormatAsync(int? id, SaveCertificationFormatRequestDto request, string currentUserId);

        Task<CertificationOperationResult> DeleteFormatAsync(int id, string currentUserId);

        Task<List<CertifierDto>> GetCertifiersAsync(int? areaId, string? search);

        Task<List<CertifierTeamDto>> GetTeamsByAreaAsync(int areaId);

        Task<List<CertifierDto>> GetCertifierCandidatesAsync(int areaId, string? search);

        Task<CertificationOperationResult> DesignateCertifierAsync(string userId, List<int> teamIds, string currentUserId);

        Task<CertificationOperationResult> RemoveCertifierAsync(string userId, string currentUserId);

        Task<List<AssignedTeamDto>> GetAssignedTeamsAsync(string certifierUserId);

        Task<CertificationOperationResult> ApplyAsync(ApplyCertificationRequestDto request, string certifierUserId);

        Task<List<CertificationDto>> GetCertificationsAsync(
            string? assignedToCertifierId, int? areaId, int? teamId, string? certifierId,
            CertificationStatus? status, string? search);

        Task<CertificationOperationResult> ResolveAsync(long id, bool approve, string currentUserId);

        Task<CertificationBreakdownDto?> GetBreakdownAsync(long id);

        Task<CertificationExportDto?> GetExportAsync(long id);
    }
}
