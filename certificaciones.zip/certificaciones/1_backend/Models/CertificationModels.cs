using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ApiCoaching.Models
{
    public class CertificationFormat : BaseEntity
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(150)]
        public string Name { get; set; } = null!;

        public int TeamId { get; set; }

        public bool IsActive { get; set; }

        [Column(TypeName = "decimal(5, 2)")]
        public decimal MinScore { get; set; }

        public string FinalFormula { get; set; } = null!;

        // Criterios, columnas, indicadores y fórmulas definidos en el constructor, serializados como JSON
        public string CriteriaJson { get; set; } = null!;

        public virtual Team Team { get; set; } = null!;
    }

    public class TeamCertifier
    {
        public int TeamId { get; set; }
        public virtual Team Team { get; set; } = null!;

        [MaxLength(50)]
        public string CertifierUserId { get; set; } = null!;
        public virtual User Certifier { get; set; } = null!;

        public DateTime DesignatedAt { get; set; }

        [MaxLength(50)]
        public string DesignatedBy { get; set; } = null!;
    }

    public class Certification : BaseEntity
    {
        [Key]
        public long Id { get; set; }

        public int TeamId { get; set; }

        [MaxLength(50)]
        public string LeaderUserId { get; set; } = null!;

        [MaxLength(50)]
        public string CertifierUserId { get; set; } = null!;

        public int? FormatId { get; set; }

        [MaxLength(150)]
        public string FormatName { get; set; } = null!;

        [Column(TypeName = "decimal(5, 2)")]
        public decimal MinScore { get; set; }

        public DateTime CertificationDate { get; set; }

        public CertificationStatus Status { get; set; }

        [Column(TypeName = "decimal(7, 2)")]
        public decimal Score { get; set; }

        [MaxLength(2000)]
        public string? Suggestions { get; set; }

        public string AnswersJson { get; set; } = null!;

        // Copia de los criterios del formato al momento de aplicar.
        // El formato puede editarse o borrarse después; la certificación conserva su estructura.
        public string? CriteriaJson { get; set; }

        // Desglose por criterio calculado al aplicar, para no depender de ediciones posteriores del formato
        public string? BreakdownJson { get; set; }

        public DateTime? ResolvedAt { get; set; }

        [MaxLength(50)]
        public string? ResolvedBy { get; set; }

        public virtual Team Team { get; set; } = null!;
        public virtual User Leader { get; set; } = null!;
        public virtual User Certifier { get; set; } = null!;
        public virtual CertificationFormat? Format { get; set; }
    }

    public enum CertificationStatus
    {
        Pending = 0,
        Approved = 1,
        Rejected = 2
    }
}
