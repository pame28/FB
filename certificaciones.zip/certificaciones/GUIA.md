# Certificaciones — guía de cambios (desde cero)

Todo lo de esta carpeta es **sobre el código actual de tu compañera**. Los archivos `.cs` y `.js`
son **completos**: se reemplaza el archivo entero. Los `.txt` son cambios puntuales a archivos
que no tengo completos (se pega solo lo indicado).

## Qué resuelve

1. **PDF de certificación con datos reales**: nuevo endpoint `GET /api/certifications/{id}/export`.
   El backend calcula notas por columna, por criterio y la final; el frontend solo dibuja.
2. **Copia de la estructura del formato** en cada certificación (`CriteriaJson`): si el formato
   se edita o se borra después, el PDF de una certificación vieja sigue saliendo igual.
3. **Borrar un formato** con certificaciones ya no falla: el FK queda en `SetNull`.
4. **Fechas en UTC** en Coaching y Certificación (antes había mezcla de hora local y UTC).

---

## BACKEND

| # | Archivo | Acción |
|---|---|---|
| 1 | `Models/CertificationModels.cs` | **Reemplazar** el archivo donde están `CertificationFormat`, `TeamCertifier`, `Certification` y `CertificationStatus`. Único cambio: propiedad `CriteriaJson` en `Certification`. |
| 2 | `Dtos/Certifications/CertificationExportDto.cs` | **Nuevo** archivo. |
| 3 | `Services/CertificationScoreCalculator.cs` | **Reemplazar**. Se agrega `ColumnNotes()`; `CriterionScore()` la usa (mismo resultado que antes). |
| 4 | `Repositories/Interfaces/ICertificationsRepository.cs` | **Reemplazar**. Se agrega `GetExportAsync`. |
| 5 | `Repositories/CertificationsRepository.cs` | **Reemplazar**. Cambios: `DateTime.UtcNow` (la bitácora sigue igual), `CriteriaJson` al aplicar, y `GetExportAsync` + `MapExportCriterion`. |
| 6 | `Endpoints/CertificationsEndpoints.cs` | **Reemplazar**. Se agrega `GET {id}/export`. |
| 7 | `Data/AppDbContext.cambios.cs.txt` | **Pegar** 3 cosas en `AppDbContext.cs` (using, FK SetNull, conversión UTC). |
| 8 | `Coaching.cambios.cs.txt` | **Pegar**: `DateTime.UtcNow` en asignaciones y quitar `AsUtc` del export de coaching. |
| 9 | — | **Compilar** (0 errores) antes de migrar. |
| 10 | `Migrations/Migracion.cambios.cs.txt` | Crear la migración, pegar el SQL en `Up()` y `Down()`, y `dotnet ef database update`. |

> Si al reemplazar algún archivo el nombre o la carpeta no coincide con el de tu proyecto,
> conserva el nombre de tu proyecto y solo reemplaza el contenido.

**Prueba (Postman):**
`GET https://apifeedbackcolaboradoresde.banpais.hn/api/certifications/{id}/export`
con el id de una certificación **aprobada**. Debe traer `criteria` con `indicators`, `columnNotes`,
`note`, `points`, y `registeredAt` / `resolvedAt` terminando en `Z`.

---

## FRONTEND

| # | Archivo | Acción |
|---|---|---|
| 11 | `api/certificationService.js` | **Reemplazar**. Se agrega `exportData(id)`. |
| 12 | `.../certification/certificationReport.js` | **Reemplazar**. El PDF usa los datos del export (`fromExport`), ya no recalcula. |
| 13 | `.../certification/useCertificationReports.js` | **Reemplazar**. `downloadPdf` pide `/export` antes de armar el PDF. |
| 14 | Revisar | Busca `.slice(0, 10)` en páginas de certificación y coaching. Si se aplica a una fecha **con hora** (p. ej. fecha de creación de un formato), cámbialo por `new Date(valor).toLocaleDateString("es-ES")`. El `date` de `mapCertification` se deja igual (es fecha sin hora). |

`certificationStore.js` **no cambia**: `computeFinal` se sigue usando para la vista previa del formulario de aplicar.

---

## Pendiente con la analista

El PDF tiene **Centro de costo**, **Director** y **Supervisor**, pero esos datos no existen en la
base de datos (salen "—"). Definir si se quitan o de dónde salen.

## Avisar a tu compañera

Estos cambios tocan su módulo (repositorio, calculadora, endpoints) y el `AppDbContext`.
