import { STATUS } from "./certificationStore";

/* =========================================================
   Reportes de Certificación
   - Excel del historial (usa exportReport)
   - PDF de una certificación aprobada (usa exportPdf)
   Cuando exista la API, solo hay que ajustar los nombres de campos aquí.
   ========================================================= */

const pad = (n) => String(n).padStart(2, "0");

// "2025-05-15" → Date local (sin desfase de zona horaria)
const isoToDate = (iso) => {
  if (!iso) return null;
  const [y, m, d] = String(iso).slice(0, 10).split("-").map(Number);
  return new Date(y, m - 1, d);
};

const dmy = (iso) => {
  const d = isoToDate(iso);
  return d ? `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}` : "—";
};

const dateTime = (value) => {
  if (!value) return "—";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  const h = d.getHours();
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(h % 12 || 12)}:${pad(d.getMinutes())} ${h < 12 ? "a. m." : "p. m."}`;
};

const STATUS_TONE = { [STATUS.approved]: "green", [STATUS.pending]: "amber", [STATUS.rejected]: "red" };

/* =========================================================
   1) EXCEL DEL HISTORIAL
   ========================================================= */

const historyColumns = [
  { header: "Equipo", key: "teamName" },
  { header: "Área", key: "area" },
  { header: "Líder certificado", key: "leaderName" },
  { header: "Certificador", key: "certifier" },
  { header: "Formato usado", key: "formatName" },
  // El puntaje solo se muestra una vez resuelta la certificación (igual que en pantalla)
  { header: "Puntaje", type: "number", value: (c) => (c.status === STATUS.pending ? null : c.score) },
  { header: "Mínimo", type: "integer", key: "minScore" },
  { header: "Fecha", type: "date", value: (c) => isoToDate(c.date) },
  { header: "Estado", key: "status", tone: (v) => STATUS_TONE[v] ?? "grey" },
];

/**
 * Datos para exportReport() con el historial filtrado.
 * filters: [{ label, value }] con los filtros aplicados en pantalla
 */
export const certificationHistoryReport = ({ title, rows, filters = [], generatedBy, hideArea = false }) => {
  const count = (s) => rows.filter((c) => c.status === s).length;
  return {
    title,
    fileName: title,
    columns: hideArea ? historyColumns.filter((c) => c.key !== "area") : historyColumns,
    rows,
    filters,
    generatedBy,
    summary: [
      { label: "Aprobadas", value: count(STATUS.approved), tone: { fg: "#166534" } },
      { label: "Pendientes", value: count(STATUS.pending), tone: { fg: "#8A5A00" } },
      { label: "No aprobadas", value: count(STATUS.rejected), tone: { fg: "#991B1B" } },
    ],
  };
};

/** Arma la lista de filtros "bonita" a partir de los selects de la pantalla */
export const historyFilters = ({ area, team, certifier, status, search }) =>
  [
    area && area !== "todas" && { label: "Área", value: area },
    team && team !== "todos" && { label: "Equipo", value: team },
    certifier && certifier !== "todos" && { label: "Certificador", value: certifier },
    status && status !== "todos" && { label: "Estado", value: status },
    search?.trim() && { label: "Líder", value: search.trim() },
  ].filter(Boolean);

/**
 * Respuesta de GET /api/certifications/{id}/export → datos que usa buildCertificationPdf().
 * El backend ya calcula las notas (por columna, por criterio y final); aquí solo se acomodan.
 */
export const fromExport = (d) => {
  const criteria = (d.criteria ?? []).map((c) => ({ ...c, noteLabel: `Nota: ${c.name}` }));

  return {
    id: d.id,
    teamName: d.teamName,
    area: d.area,
    leaderName: d.leaderName,
    certifier: d.certifierName,
    formatName: d.formatName,
    date: d.date,
    minScore: d.minScore,
    suggestions: d.suggestions,
    registeredAt: d.registeredAt,
    resolvedBy: d.resolvedByName,
    resolvedAt: d.resolvedAt,
    criteria,
    rows: criteria.map((c) => ({
      criterion: c,
      colNotes: Object.fromEntries((c.columnNotes ?? []).map((n) => [n.column, n.isNa ? "NA" : n.value])),
      nota: c.note,
      points: c.points,
    })),
    // { [criterioId]: { [indicadorId]: { [columna]: valor, __obs } } }
    answers: Object.fromEntries(
      criteria.map((c) => [
        c.id,
        Object.fromEntries(c.indicators.map((i) => [i.id, { ...i.values, __obs: i.observation ?? "" }])),
      ])
    ),
    total: Number(d.score ?? 0),
    passes: Boolean(d.passes),
  };
};

/* =========================================================
   2) PDF DE UNA CERTIFICACIÓN (estructura del anexo)
   ========================================================= */

/** Certificacion_[NombreEquipo]_[Fecha].pdf */
export const certificationFileName = (cert) => {
  const team = String(cert.teamName ?? "Equipo")
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9]+/g, "_").replace(/^_|_$/g, "");
  return `Certificacion_${team}_${dmy(cert.date).replace(/\//g, "-")}.pdf`;
};

const GREY = "#6B7A8F";
const LIGHT = "#F4F8FD";
const LINE = "#E1E8F0";
const TEXT = "#22303F";
const SUB = "#1F4E79"; // azul intermedio para encabezados de tabla
const M = 34;

// Colores de las calificaciones (CE verde, NCE rojo, NA gris)
const GRADE = {
  CE: { bg: "#DCFCE7", fg: "#166534" },
  NCE: { bg: "#FEE2E2", fg: "#991B1B" },
  NA: { bg: "#EEF1F5", fg: "#5B6B80" },
};

const noLines = {
  hLineWidth: () => 0, vLineWidth: () => 0,
  paddingLeft: () => 0, paddingRight: () => 0, paddingTop: () => 0, paddingBottom: () => 0,
};

const gridLines = {
  hLineWidth: () => 0.6, vLineWidth: () => 0.6,
  hLineColor: () => LINE, vLineColor: () => LINE,
  paddingLeft: () => 6, paddingRight: () => 6, paddingTop: () => 5, paddingBottom: () => 5,
};

const noteText = (v) => (v === "NA" ? "NA" : typeof v === "number" ? `${v}%` : "—");

const valueCell = (raw, indicatorType) => {
  const v = raw === undefined || raw === null ? "" : String(raw).trim();
  if (!v) return { text: "—", color: "#A3ADBB", alignment: "center" };
  const grade = GRADE[v.toUpperCase()];
  if (grade) return { text: ` ${v.toUpperCase()} `, bold: true, fontSize: 7.5, color: grade.fg, background: grade.bg, alignment: "center" };
  const suffix = indicatorType === "%" && !v.endsWith("%") ? "%" : "";
  return { text: `${v}${suffix}`, alignment: indicatorType === "Texto" ? "left" : "center" };
};

const titleBar = (config, text, margin = [0, 12, 0, 0]) => ({
  margin,
  table: { widths: ["*"], body: [[{ text, bold: true, fontSize: 9.5, color: "#FFFFFF", fillColor: config.primaryColor, margin: [10, 6, 10, 6] }]] },
  layout: noLines,
});

/**
 * Devuelve la función que exportPdf() usa para armar el documento.
 * @param {object} cert  Certificación (con criteria y answers)
 * @param {object} options  { generatedBy }
 */
export const buildCertificationPdf = (cert, { generatedBy } = {}) => (config, { generatedAt }) => {
  const { criteria = [], rows = [], total = 0, passes = false } = cert;
  const fileName = certificationFileName(cert);
  const brand = config.brandName ?? config.system ?? "eCoaching";
  const pageW = config.pageSize === "A4" ? 595.28 : 612;

  /* ---------- Encabezado ---------- */
  // pdfmake no centra verticalmente dentro de una celda: se calcula el margen
  // superior del título a partir del alto real del logo.
  const LOGO_BOX = [150, 50]; // tamaño máximo del logo (ancho, alto)
  const PAD = 8; // margen arriba y abajo de la banda
  const TITLE_LINE = 18; // alto aproximado de una línea de título a 15 pt
  const logo = config.logoOnDark;
  const logoH = logo?.width
    ? Math.min(LOGO_BOX[1], (LOGO_BOX[0] * logo.height) / logo.width)
    : 20;
  const bannerH = logoH + PAD * 2;
  const titleTop = Math.max(PAD, (bannerH - TITLE_LINE) / 2);

  const header = [
    {
      table: {
        widths: ["*", "auto"],
        body: [[
          {
            text: `Formato Certificación "${cert.teamName}"`,
            fontSize: 15, bold: true, color: "#FFFFFF",
            fillColor: config.primaryColor,
            margin: [16, titleTop, 8, Math.max(PAD, bannerH - titleTop - TITLE_LINE)],
          },
          logo
            ? { image: logo.dataUrl, fit: LOGO_BOX, fillColor: config.primaryColor, margin: [8, PAD, 16, PAD] }
            : { text: brand, bold: true, fontSize: 16, color: config.accentColor, fillColor: config.primaryColor, margin: [8, titleTop, 16, PAD] },
        ]],
      },
      layout: noLines,
    },
    { canvas: [{ type: "rect", x: 0, y: 0, w: pageW - M * 2, h: 3, color: config.accentColor }] },
  ];

  /* ---------- Datos generales + criterios / pesos ---------- */
  const info = [
    ["Centro de costo", cert.costCenter],
    ["Agencia / Equipo", cert.teamName],
    ["Certificador", cert.certifier],
    ["Líder evaluado", cert.leaderName],
    ["Director", cert.director],
    ["Supervisor", cert.supervisor],
    ["Fecha", dmy(cert.date)],
  ];

  const infoTable = {
    table: {
      widths: [82, "*"],
      body: info.map(([label, value]) => [
        { text: label, color: GREY, fontSize: 8, fillColor: LIGHT },
        { text: value || "—", color: value ? TEXT : "#A3ADBB", fontSize: 8.5 },
      ]),
    },
    layout: gridLines,
  };

  const weightsTable = {
    table: {
      widths: ["*", 50],
      body: [
        [
          { text: "CRITERIO", bold: true, fontSize: 7.5, color: config.primaryColor, fillColor: "#EAF0F7", alignment: "center" },
          { text: "PESO", bold: true, fontSize: 7.5, color: "#FFFFFF", fillColor: config.primaryColor, alignment: "center" },
        ],
        ...criteria.map((c) => [
          { text: c.name, fontSize: 8 },
          { text: `${c.weight}%`, bold: true, fontSize: 8, alignment: "center", color: config.primaryColor },
        ]),
        [
          { text: "NOTA FINAL", bold: true, fontSize: 8.5, color: "#FFFFFF", fillColor: config.primaryColor, alignment: "center" },
          { text: `${total}%`, bold: true, fontSize: 9, color: "#FFFFFF", fillColor: passes ? "#0F6E56" : "#A32D2D", alignment: "center" },
        ],
      ],
    },
    layout: gridLines,
  };

  const content = [
    ...header,
    { margin: [0, 12, 0, 0], columns: [{ width: "55%", ...infoTable }, { width: 14, text: "" }, { width: "*", ...weightsTable }] },
  ];

  /* ---------- Un bloque por criterio ---------- */
  rows.forEach(({ criterion: c, colNotes }, idx) => {
    content.push(titleBar(config, `${idx + 1}.- ${c.name}  |  Peso: ${c.weight}%`, [0, 14, 0, 0]));

    if (c.description) {
      content.push({
        table: { widths: ["*"], body: [[{ text: c.description, fontSize: 8, italics: true, color: "#3D5A80", fillColor: "#EAF3FC", margin: [10, 5, 10, 5] }]] },
        layout: noLines,
      });
    }

    const head = [
      { text: "Indicador", bold: true, fontSize: 7.5, color: "#FFFFFF", fillColor: SUB },
      ...c.columns.map((col) => ({ text: col.toUpperCase(), bold: true, fontSize: 7, color: "#FFFFFF", fillColor: SUB, alignment: "center" })),
      { text: "Observaciones (detallar lo indagado)", bold: true, fontSize: 7.5, color: "#FFFFFF", fillColor: SUB },
    ];

    const body = c.indicators.map((ind, i) => {
      const answer = cert.answers?.[c.id]?.[ind.id] ?? {};
      const fill = i % 2 === 1 ? "#F8FAFC" : null;
      return [
        { text: ind.name, bold: true, fontSize: 8, color: config.primaryColor, fillColor: fill },
        ...c.columns.map((col) => ({ ...valueCell(answer[col], ind.type), fillColor: fill })),
        { text: answer.__obs || "", fontSize: 7.5, color: "#3D4B5C", fillColor: fill },
      ];
    });

    const noteRow = [
      { text: (c.noteLabel ?? "Nota del criterio").toUpperCase(), bold: true, fontSize: 7.5, color: "#FFFFFF", fillColor: "#2D5A88" },
      ...c.columns.map((col) => ({
        text: col in colNotes ? noteText(colNotes[col]) : "",
        bold: true, fontSize: 8, color: "#FFFFFF", fillColor: "#2D5A88", alignment: "center",
      })),
      { text: "", fillColor: "#2D5A88" },
    ];

    content.push({
      table: {
        headerRows: 1,
        dontBreakRows: true,
        widths: [130, ...c.columns.map(() => 52), "*"],
        body: [head, ...body, noteRow],
      },
      layout: gridLines,
    });
  });

  /* ---------- Desglose del puntaje final ---------- */
  content.push({
    margin: [0, 16, 0, 0],
    unbreakable: true,
    table: {
      widths: [80, ...rows.map(() => "*"), 80],
      body: [[
        { text: "DESGLOSE PUNTAJE FINAL", bold: true, fontSize: 8, color: "#FFFFFF", fillColor: config.primaryColor, margin: [4, 6, 4, 6] },
        ...rows.map((r, i) => ({
          fillColor: config.primaryColor,
          alignment: "center",
          margin: [2, 5, 2, 5],
          stack: [
            { text: `C${i + 1} · ${r.criterion.weight}%`, fontSize: 7, color: "#C9D6E6" },
            { text: `${r.nota ?? 0}% × ${r.criterion.weight}% = ${r.points} pts`, fontSize: 7.5, bold: true, color: "#FFFFFF", margin: [0, 2, 0, 0] },
          ],
        })),
        {
          fillColor: passes ? "#0F6E56" : "#A32D2D",
          alignment: "center",
          margin: [2, 4, 2, 4],
          stack: [
            { text: "NOTA FINAL", fontSize: 7, bold: true, color: "#FFFFFF" },
            { text: `${total}%`, fontSize: 14, bold: true, color: "#FFFFFF" },
            { text: `Mín. ${cert.minScore ?? "—"}%`, fontSize: 6.5, color: "#E6F2EC" },
          ],
        },
      ]],
    },
    layout: { ...noLines, vLineWidth: (i, node) => (i === 0 || i === node.table.widths.length ? 0 : 1), vLineColor: () => "#2D5A88" },
  });

  /* ---------- Sugerencias ---------- */
  content.push(
    titleBar(config, "SUGERENCIAS, RECOMENDACIONES Y COMPROMISOS", [0, 14, 0, 0]),
    {
      table: {
        widths: ["*"],
        body: [[{
          text: cert.suggestions || "Sin sugerencias registradas.",
          fontSize: 8.5,
          lineHeight: 1.3,
          italics: !cert.suggestions,
          color: cert.suggestions ? TEXT : "#A3ADBB",
          margin: [10, 10, 10, 18],
        }]],
      },
      layout: { ...noLines, hLineWidth: (i) => (i === 1 ? 0.6 : 0), vLineWidth: () => 0.6, hLineColor: () => LINE, vLineColor: () => LINE },
    }
  );

  /* ---------- Aprobación del certificador ---------- */
  content.push({
    margin: [0, 22, 0, 0],
    unbreakable: true,
    alignment: "center",
    stack: [
      { text: "APROBACIÓN DEL CERTIFICADOR", fontSize: 8, bold: true, color: GREY, characterSpacing: 0.5 },
      { canvas: [{ type: "line", x1: 0, y1: 6, x2: 240, y2: 6, lineWidth: 1.5, lineColor: config.primaryColor }] },
      { text: `${cert.certifier ?? "—"}  |  ${dateTime(cert.registeredAt)}`, fontSize: 9, bold: true, color: config.primaryColor, margin: [0, 8, 0, 0] },
      { text: "Nombre del certificador  |  Fecha y hora de registro", fontSize: 7, color: "#A3ADBB", margin: [0, 2, 0, 0] },
      ...(cert.resolvedBy
        ? [{ text: `Aprobada por ${cert.resolvedBy} el ${dateTime(cert.resolvedAt)}`, fontSize: 7.5, color: GREY, margin: [0, 8, 0, 0] }]
        : []),
    ],
  });

  /* ---------- Pie de página ---------- */
  const footer = (currentPage, pageCount) => ({
    margin: [M, 8, M, 0],
    stack: [
      { canvas: [{ type: "line", x1: 0, y1: 0, x2: pageW - M * 2, y2: 0, lineWidth: 0.6, lineColor: LINE }] },
      {
        margin: [0, 5, 0, 0],
        columns: [
          {
            width: "*",
            fontSize: 6.5,
            color: "#A3ADBB",
            text: [
              `${brand}${config.organization ? ` ${config.organization}` : ""}  |  ${fileName}  |  Documento generado automáticamente`,
              generatedBy ? `  ·  Generado por ${generatedBy}` : "",
              `  ·  ${dateTime(generatedAt)}`,
            ].join(""),
          },
          { width: 60, text: `Página ${currentPage} de ${pageCount}`, alignment: "right", fontSize: 7, color: GREY },
        ],
      },
    ],
  });

  return {
    pageSize: config.pageSize ?? "LETTER",
    pageOrientation: "portrait",
    pageMargins: [M, 28, M, 44],
    info: { title: fileName.replace(/\.pdf$/, ""), author: config.organization, creator: brand },
    footer,
    content,
    defaultStyle: { fontSize: 8.5, color: TEXT },
  };
};
