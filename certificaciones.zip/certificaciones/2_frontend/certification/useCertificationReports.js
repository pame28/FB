import { useState } from "react";
import { useToast } from "../../../shared/components";
import { useAuthStore } from "../../../hooks/useAuthStore";
import { displayName } from "../../../helpers/format";
import { exportPdf, exportReport } from "../../../shared/reports";
import { certificationService } from "../../../api/certificationService";
import { buildCertificationPdf, certificationFileName, certificationHistoryReport, fromExport } from "./certificationReport";
import { STATUS } from "./certificationStore";

/**
 * Descargas de la épica Certificación, compartidas por las 3 pantallas.
 * busy: "pdf-<id>" | "excel" | null  (para deshabilitar botones mientras se genera)
 */
export const useCertificationReports = () => {
  const toast = useToast();
  const { user } = useAuthStore();
  const [busy, setBusy] = useState(null);
  const generatedBy = displayName(user);

  /** PDF de una certificación (solo aprobadas). Los datos completos vienen de /export */
  const downloadPdf = async (cert) => {
    if (cert.status !== STATUS.approved) {
      toast.error("El PDF solo está disponible para certificaciones aprobadas");
      return;
    }
    const fileName = certificationFileName(cert);
    setBusy(`pdf-${cert.id}`);
    try {
      const data = fromExport(await certificationService.exportData(cert.id));
      await exportPdf(buildCertificationPdf(data, { generatedBy }), fileName);
      toast.success("PDF generado", fileName);
    } catch (err) {
      console.error(err);
      toast.error("No se pudo generar el PDF", "Intenta de nuevo en unos momentos.");
    } finally {
      setBusy(null);
    }
  };

  /** Excel del historial filtrado (filas que ya están en pantalla) */
  const exportHistory = async ({ title, rows, filters, hideArea }) => {
    setBusy("excel");
    try {
      await exportReport("excel", certificationHistoryReport({ title, rows, filters, hideArea, generatedBy }));
      toast.success("Excel generado", `Se exportaron ${rows.length} certificaciones.`);
    } catch (err) {
      console.error(err);
      toast.error("No se pudo generar el Excel", "Intenta de nuevo en unos momentos.");
    } finally {
      setBusy(null);
    }
  };

  return { downloadPdf, exportHistory, busy };
};
