import { apiFeedbackAuthorized } from "./APIS";
import { endpointsAPI } from "./endpointApi";

const base = endpointsAPI.certifications;

const params = (obj) => Object.fromEntries(Object.entries(obj).filter(([, v]) => v !== "" && v !== null && v !== undefined));

export const certificationService = {
  /* Formatos */
  formats: async () => {
    const { data } = await apiFeedbackAuthorized.get(`${base}/formats`);
    return data.data ?? [];
  },

  // body: { name, teamId, criteria, finalFormula, minScore }
  createFormat: async (body) => {
    const { data } = await apiFeedbackAuthorized.post(`${base}/formats`, body);
    return data.data;
  },

  updateFormat: async (id, body) => {
    const { data } = await apiFeedbackAuthorized.put(`${base}/formats/${id}`, body);
    return data.data;
  },

  removeFormat: async (id) => {
    const { data } = await apiFeedbackAuthorized.delete(`${base}/formats/${id}`);
    return data.data;
  },

  /* Gestión de certificadores */
  certifiers: async ({ areaId, search } = {}) => {
    const { data } = await apiFeedbackAuthorized.get(`${base}/certifiers`, { params: params({ areaId, search }) });
    return data.data ?? [];
  },

  teamsByArea: async (areaId) => {
    const { data } = await apiFeedbackAuthorized.get(`${base}/certifiers/teams`, { params: { areaId } });
    return data.data ?? [];
  },

  candidates: async (areaId, search) => {
    const { data } = await apiFeedbackAuthorized.get(`${base}/certifiers/candidates`, { params: params({ areaId, search }) });
    return data.data ?? [];
  },

  designate: async (userId, teamIds) => {
    const { data } = await apiFeedbackAuthorized.post(`${base}/certifiers`, { userId, teamIds });
    return data.data;
  },

  removeCertifier: async (userId) => {
    const { data } = await apiFeedbackAuthorized.delete(`${base}/certifiers/${userId}`);
    return data.data;
  },

  /* Aplicar certificación */
  myTeams: async () => {
    const { data } = await apiFeedbackAuthorized.get(`${base}/my-teams`);
    return data.data ?? [];
  },

  // body: { teamId, leaderUserId, date, answers, suggestions }
  apply: async (body) => {
    const { data } = await apiFeedbackAuthorized.post(base, body);
    return data.data;
  },

  /* Historiales */
  mine: async () => {
    const { data } = await apiFeedbackAuthorized.get(`${base}/mine`);
    return data.data ?? [];
  },

  all: async ({ areaId, teamId, certifierId, status, search } = {}) => {
    const { data } = await apiFeedbackAuthorized.get(base, { params: params({ areaId, teamId, certifierId, status, search }) });
    return data.data ?? [];
  },

  breakdown: async (id) => {
    const { data } = await apiFeedbackAuthorized.get(`${base}/${id}/breakdown`);
    return data.data;
  },

  // Datos completos para el PDF (criterios, respuestas, notas y aprobación)
  exportData: async (id) => {
    const { data } = await apiFeedbackAuthorized.get(`${base}/${id}/export`);
    return data.data;
  },

  approve: async (id) => {
    const { data } = await apiFeedbackAuthorized.post(`${base}/${id}/approve`);
    return data.data;
  },

  reject: async (id) => {
    const { data } = await apiFeedbackAuthorized.post(`${base}/${id}/reject`);
    return data.data;
  },
};
